const INBOX = require('../models2/inboxnew');
const USER = require('../models2/usernew');
const CONTENT = require('../models/content');
const DEVICE = require('../models/device');
const { getName } = require('country-list');
const OneSignal = require('onesignal-node');
const axios = require('axios');

const { updateReplyAndBadge } = require('../helpers/replyHelper');

// Initialize the OneSignal Client
const client = new OneSignal.Client(
    '69c53fa2-c84d-42a9-b377-1e4fff31fa18',
    'OTMxMGNiMmItYzgzZi00ODU0LTgyNjUtZmYwY2M1NWFmNGZk'
);

const notificationContent = {
    en: [
        {
            title: "New anonymous message 📩",
            desc: "Someone just sent you a message secretly. Tap to read it."
        },
        {
            title: "You got an anonymous message 👀",
            desc: "Someone sent you a message without revealing their name. Tap to check it."
        },
        {
            title: "Anonymous message received 🔒",
            desc: "Someone sent you a message without their name. Tap to open and read it."
        }
    ],
    hi: [
        {
            title: "नया गुप्त संदेश 📩",
            desc: "किसी ने आपको गुप्त रूप से संदेश भेजा है। पढ़ने के लिए टैप करें।"
        },
        {
            title: "आपको एक गुप्त संदेश मिला 👀",
            desc: "किसी ने बिना नाम बताए आपको संदेश भेजा है। चेक करने के लिए टैप करें।"
        },
        {
            title: "गुप्त संदेश प्राप्त हुआ 🔒",
            desc: "किसी ने बिना अपना नाम बताए संदेश भेजा है। खोलने के लिए टैप करें।"
        }
    ],
    mr: [
        {
            title: "नवीन गुप्त संदेश 📩",
            desc: "कोणीतरी तुम्हाला गुप्तपणे संदेश पाठवला आहे. वाचण्यासाठी टॅप करा."
        },
        {
            title: "तुम्हाला एक गुप्त संदेश आला 👀",
            desc: "कोणीतरी नाव न सांगता संदेश पाठवला आहे. पाहण्यासाठी टॅप करा."
        },
        {
            title: "गुप्त संदेश प्राप्त झाला 🔒",
            desc: "कोणीतरी आपले नाव न सांगता संदेश पाठवला आहे. उघडण्यासाठी टॅप करा."
        }
    ],
    ta: [
        {
            title: "புதிய ரகசிய செய்தி 📩",
            desc: "யாரோ உங்களுக்கு ரகசியமாக ஒரு செய்தி அனுப்பியுள்ளார். படிக்க தட்டவும்."
        },
        {
            title: "உங்களுக்கு ஒரு ரகசிய செய்தி வந்துள்ளது 👀",
            desc: "யாரோ தங்கள் பெயரை சொல்லாமல் ஒரு செய்தி அனுப்பியுள்ளனர். பார்க்க தட்டவும்."
        },
        {
            title: "ரகசிய செய்தி பெறப்பட்டது 🔒",
            desc: "யாரோ பெயர் தெரியாமல் ஒரு செய்தி அனுப்பியுள்ளார். திறக்க தட்டவும்."
        }
    ],
    enhi: [
        {
            title: "New anonymous message aaya hai 📩",
            desc: "Kisi ne aapko secretly message bheja hai. Read karne ke liye tap karo."
        },
        {
            title: "Aapko anonymous message mila 👀",
            desc: "Kisi ne bina naam bataye message bheja hai. Check karne ke liye tap karo."
        },
        {
            title: "Anonymous message receive hua 🔒",
            desc: "Kisi ne bina apna naam bataye message bheja hai. Open karne ke liye tap karo."
        }
    ]
};

const getRandomContentByLang = (lang) => {
    const supportedLangs = ['en', 'hi', 'mr', 'ta', 'enhi'];

    let finalLang;

    if (lang === 'en') {
        // 🔥 50-50 random between en & enhi
        finalLang = Math.random() < 0.5 ? 'en' : 'enhi';
    } else {
        finalLang = supportedLangs.includes(lang) ? lang : 'en';
    }

    const options = notificationContent[finalLang];
    const randomOption = options[Math.floor(Math.random() * options.length)];

    return {
        title: randomOption.title,
        desc: randomOption.desc,
        lang: finalLang
    };
};

async function sendNotification(playerId, lang = 'en', data = {}, iconUrl = '') {

    if (!playerId) {
        throw new Error('Invalid player ID');
    }


    const { title, desc, lang: finalLang } = getRandomContentByLang(lang);

    const notification = {
        include_player_ids: [playerId],
        data: {
            type: 'inbox',
            ...data,
        },
        headings: {
            en: title
        },
        contents: {
            en: desc
        },
        small_icon: "ic_stat_onesignal_default",
        large_icon: iconUrl || undefined
    };

    try {
        const response = await client.createNotification(notification);

        return {
            success: true,
            response: response.body
        };
    } catch (error) {
        console.error("❌ Error:", error);

        return {
            success: false,
            error: error.message || error
        };
    }
}

const defaultHintImages = [
    "https://lol-image-bucket.s3.ap-south-1.amazonaws.com/hintimage1.png",
    "https://lol-image-bucket.s3.ap-south-1.amazonaws.com/hintimage2.png",
    // "https://lol-image-bucket.s3.ap-south-1.amazonaws.com/hintimage3.png",
    "https://lol-image-bucket.s3.ap-south-1.amazonaws.com/hintimage4.png",
];


async function translateText(text, from, to) {
    try {
        const res = await axios.get("https://api.mymemory.translated.net/get", {
            params: {
                q: text,
                langpair: `${from}|${to}`
            }
        });
        return res.data.responseData.translatedText;
    } catch (err) {
        console.error(`Translation error (${to}):`, err.message);
        return text; // fallback: return original text
    }
}

exports.Create = async function (req, res, next) {
    try {
        const { webCategory, timestamp } = req.body;

        // =================== Handle hint ===================
        req.body.hint = req.body.hint && req.body.hint !== "undefined" && req.body.hint !== "null" ? req.body.hint : "-";

        if (req.uploadedImageUrl) {
            req.body.hintImage = req.uploadedImageUrl;
        } else if (req.body.uploadedImage && req.body.uploadedImage.trim() !== '') {
            req.body.hintImage = req.body.uploadedImage;
        } else {
            req.body.hintImage =
                defaultHintImages[Math.floor(Math.random() * defaultHintImages.length)];
        }

        req.body.hintAudio = req.hintAudioUrl || null;


        // =================== Handle user & block list ===================
        const User = await USER.findOne({ id: req.body.id });
        if (!User) throw new Error('User Not Found');
        if (User.blockList && User.blockList.includes(req.body.ip)) {
            throw new Error('You Are Blocked For This Link');
        }

        // =================== Handle language content ===================
        const data = User.question || [];

        // 🔥 find once
        let matchedItem;


        if (webCategory === "UGljIFJvYXN0") {
            matchedItem = data.find(
                item =>
                    item.category === webCategory &&
                    String(item.answer?.timestamp) === String(timestamp)
            );
        } else {
            matchedItem = data.find(item => item.category === webCategory);
        }

        

        // ✅ set values
        req.body.question = matchedItem?.question || "";
        const lanText = matchedItem?.lan || "en";

        console.log("Matched question:", req.body.question, "Language:", webCategory);


        const contentList = await CONTENT.find();
        const randomItem = contentList[Math.floor(Math.random() * contentList.length)];
        let finalContent = randomItem.Content || "-";

        if (lanText === "hi") finalContent = randomItem.hiContent || finalContent;
        else if (lanText === "mr") finalContent = randomItem.mrContent || finalContent;
        else if (lanText === "ta") finalContent = randomItem.taContent || finalContent;
        else if (lanText === "enhi") finalContent = randomItem.enhiContent || finalContent;

        req.body.hintContent = finalContent;


        // =================== Handle location ===================
        const fetch = (await import('node-fetch')).default;

        const getClientIp = (req) => {
            const xForwardedFor = req.headers['x-forwarded-for'];
            if (xForwardedFor) return xForwardedFor.split(',')[0].trim();
            return req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket?.remoteAddress;
        };

        const ip = getClientIp(req);

        // console.log(`Client IP: ${ip}, User ID: ${req.body.id}`)

        if (ip && req.body.userLocation === "allow") {
            try {
                const url = `http://ip-api.com/json/${ip}?fields=status,country,regionName,city,query`;
                const response = await fetch(url);
                const data = await response.json();
                if (data.status === "success") {
                    let city = data.city || "-";
                    let region = data.regionName || "-";
                    let country = data.country || "-";
                    
                    // Translate location if language is not English
                    if (lanText && lanText !== "en") {
                        city = await translateText(city, "en", lanText);
                        region = await translateText(region, "en", lanText);
                        country = await translateText(country, "en", lanText);
                    }

                    req.body.location = `${city} ${region}`;
                    req.body.country = country;
                } else {
                    req.body.location = "-";
                    req.body.country = "-";
                }
            } catch (error) {
                console.error("Error fetching location:", error);
                req.body.location = "-";
                req.body.country = "-";
            }
        } else {
            req.body.location = '-';
            req.body.country = '-';
        }

        req.body.ip = req.body.deviceIp;

        // =================== Daily Limit Check (IP + Category) ===================

        // get today's start & end
        const now = new Date();

        const startOfDay = new Date(Date.UTC(
            now.getUTCFullYear(),
            now.getUTCMonth(),
            now.getUTCDate(),
            0, 0, 0, 0
        ));

        const endOfDay = new Date(Date.UTC(
            now.getUTCFullYear(),
            now.getUTCMonth(),
            now.getUTCDate(),
            23, 59, 59, 999
        ));

        const device = await DEVICE.findOne({
            webDeviceIds: req.body.deviceIp
        });

        // count today's entries
        if (!device) {
            todayCount = await INBOX.countDocuments({
                category: req.body.category,
                ip: req.body.deviceIp,
                createdAt: {
                    $gte: startOfDay,
                    $lte: endOfDay
                }
            });

            // if limit reached → throw error
            if (todayCount >= 3) {
                throw new Error("You have reached today's limit for this category");
            }
        }
        // =================== Handle time ===================
        let time = new Date().toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: 'numeric',
            hour12: true,
            timeZone: 'Asia/Kolkata'
        });

        // Translate time if language is not English
        if (lanText && lanText !== "en") {
            time = await translateText(time, "en", lanText);
        }
        req.body.time = time;

        if (!req.body.confessionVoice) {
            req.body.confessionVoice = req.ques5audioUrl
        }

        if (!req.body.roastVoice) {
            req.body.roastVoice = req.ques8audioUrl
        }

        // =================== Handle answer object ===================
        req.body.answer = {
            ...req.body.answer,
            ...(req.body.word && { word: req.body.word }),
            ...(req.contentFileUrl && { contentFile: req.contentFileUrl }),
            ...(req.body.image && { image: req.body.image }),
            ...(req.body.comment && { comment: req.body.comment }),
            ...(req.body.quetype && { quetype: req.body.quetype }),
            ...(req.body.annoyimage && { annoyimage: req.body.annoyimage }),
            ...(req.body.nickname && { nickname: req.body.nickname }),
            ...(req.body.annoycardtitle && { annoycardtitle: JSON.parse(req.body.annoycardtitle) }),
            ...(req.body.annoyans && { annoyans: JSON.parse(req.body.annoyans) }),
            ...(req.body.cardBg && { cardBg: req.body.cardBg }),
            ...(req.body.shapeUrl && { shapeUrl: req.body.shapeUrl }),
            ...(req.body.fontname && { fontname: req.body.fontname }),
            ...(req.body.shapename && { shapename: req.body.shapename }),
            ...(req.body.emotionBg && { emotionBg: req.body.emotionBg }),
            ...(req.body.emotionEmoji && { emotionEmoji: req.body.emotionEmoji }),
            ...(req.body.emotionContent && { emotionContent: req.body.emotionContent }),
            ...(req.body.emotionTitle && { emotionTitle: req.body.emotionTitle }),
            ...(req.emotionVoiceUrl && { emotionVoice: req.emotionVoiceUrl }),
            ...(req.body.confessionType && { confessionType: req.body.confessionType }),
            ...(req.body.confessionTitle && { confessionTitle: req.body.confessionTitle }),
            ...(req.body.confessionContent && { confessionContent: req.body.confessionContent }),
            ...(req.body.confessionEmoji && { confessionEmoji: req.body.confessionEmoji }),
            ...(req.body.confessionVoice && { confessionVoice: req.body.confessionVoice }),
            ...(req.body.hotnessBg && { hotnessBg: req.body.hotnessBg }),
            ...(req.body.hotnessName && { hotnessName: req.body.hotnessName }),
            ...(req.body.hotnessEmoji && { hotnessEmoji: req.body.hotnessEmoji }),
            ...(req.body.hotnessHand && { hotnessHand: req.body.hotnessHand }),
            ...(req.body.hotnessComment && { hotnessComment: req.body.hotnessComment }),
            ...(req.body.friendBg && { friendBg: req.body.friendBg }),
            ...(req.body.friendName && { friendName: req.body.friendName }),
            ...(req.body.friendEmoji && { friendEmoji: req.body.friendEmoji }),
            ...(req.body.friendContent && { friendContent: req.body.friendContent }),
            ...(req.body.roastType && { roastType: req.body.roastType }),
            ...(req.body.roastContent && { roastContent: req.body.roastContent }),
            ...(req.body.roastEmoji && { roastEmoji: req.body.roastEmoji }),
            ...(req.body.roastVoice && { roastVoice: req.body.roastVoice }),
            ...(req.body.bluffBg && { bluffBg: req.body.bluffBg }),
            ...(req.body.bluffContent && { bluffContent: req.body.bluffContent }),
            ...(req.body.bluffEmoji && { bluffEmoji: req.body.bluffEmoji }),
            ...(req.body.challengeContent && { challengeContent: req.body.challengeContent }),
            ...(req.body.heavenHellQue && { heavenHellQue: JSON.parse(req.body.heavenHellQue) }),
            ...(req.body.heavenHellAns && { heavenHellAns: JSON.parse(req.body.heavenHellAns) }),
            ...(req.body.heavenHellContent && { heavenHellContent: req.body.heavenHellContent }),
            ...(req.body.heavenHellBg && { heavenHellBg: req.body.heavenHellBg }),
            ...(req.body.heavenHellAvatarImg && { heavenHellAvatarImg: req.body.heavenHellAvatarImg }),
            ...(req.body.heavenHellBgMdlImg && { heavenHellBgMdlImg: req.body.heavenHellBgMdlImg }),
            ...(req.body.heavenHellType && { heavenHellType: req.body.heavenHellType }),
        };
        // =================== rePLY and badge update (async) ===================

        await updateReplyAndBadge(req.body.id, req.body.category);

        // =================== Create INBOX ===================
        const dataCreate = await INBOX.create(req.body);
        const filteredData = dataCreate.toObject();
        delete filteredData.__v;
        delete filteredData._id;

        res.status(201).json({
            status: 1,
            message: 'Card Created Successfully',
            data: filteredData
        });

        // =================== Notifications (async) ===================
        const playerIds = User.deviceToken || [];

        const iconUrl = 'https://lol-image-bucket.s3.ap-south-1.amazonaws.com/logo.png';
        (async () => {
            for (const token of playerIds) {
                if (token && token.trim() !== '') {
                    try {
                        await sendNotification(token, User.language, { customKey: 'customValue' }, iconUrl);
                    } catch (notifyErr) {
                        console.error("Notification failed for token:", token, notifyErr);
                    }
                }
            }
        })();

    } catch (error) {
        console.error('Full error object:', error);
        res.status(400).json({
            status: 0,
            message: error.message,
        });
    }
};



exports.Read = async function (req, res, next) {
    try {
        const { id } = req.body;
        const dataRead = await INBOX.find({ id: id })
            .select('-__v -id')
            .sort({ createdAt: -1 });

        if (!dataRead || dataRead.length === 0) {
            return res.status(200).json({
                status: 2,
                message: 'No Inbox Found'
            });
        }

        // Customize the response
        const customizedData = dataRead.map(item => {
            let answerData = {};

            if (item.category === 'V2hvVGFsa2lu') {
                answerData = {
                    word: item.answer?.word,
                    contentFile: item.answer?.contentFile
                };
            } else if (item.category === 'UGljIFJvYXN0') {
                answerData = {
                    image: item.answer?.image,
                    comment: item.answer?.comment,
                    quetype: item.answer?.quetype
                };
            } else if (item.category === 'QW5ub3kgZnVuIENhcmQ=') {
                answerData = {
                    annoyimage: item.answer?.annoyimage,
                    shapename: item.answer?.shapename,
                    nickname: item.answer?.nickname,
                    shapeUrl: item.answer?.shapeUrl,
                    fontname: item.answer?.fontname,
                    annoycardtitle: item.answer?.annoycardtitle,
                    annoyans: item.answer?.annoyans,
                    cardBg: item.answer?.cardBg,
                };
            } else {
                answerData = {
                    word: item.answer?.word,
                    contentFile: item.answer?.contentFile
                };
            }

            return {
                _id: item._id,
                category: item.category,
                question: item.question,
                hint: item.hint,
                hintImage: item.hintImage && item.hintImage.trim() !== ''
                    ? item.hintImage
                    : defaultHintImages[Math.floor(Math.random() * defaultHintImages.length)],
                location: item.location,
                country: item.country,
                ip: item.ip,
                time: item.time,
                createdAt: item.createdAt,
                updatedAt: item.updatedAt,
                answer: answerData
            };
        });

        res.status(200).json({
            status: 1,
            message: 'Data Found Successfully',
            data: customizedData,
        });

    } catch (error) {
        res.status(400).json({
            status: 0,
            error: error.message,
        });
    }
};

// ================= inbox pagination add ==================
exports.ReadPagination = async function (req, res, next) {
    try {
        const { id, page = 1, limit = 15 } = req.body;

        const skip = (page - 1) * limit;

        // Count total records
        const total = await INBOX.countDocuments({ id: id });

        const dataRead = await INBOX.find({ id: id })
            .select('-__v -id')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);

        if (!dataRead || dataRead.length === 0) {
            return res.status(200).json({
                status: 2,
                message: 'No Inbox Found'
            });
        }

        // Customize the response
        const customizedData = dataRead.map(item => {
            let answerData = {};

            if (item.category === 'V2hvVGFsa2lu') {
                answerData = {
                    word: item.answer?.word,
                    contentFile: item.answer?.contentFile
                };
            } else if (item.category === 'UGljIFJvYXN0') {
                answerData = {
                    image: item.answer?.image,
                    comment: item.answer?.comment,
                    quetype: item.answer?.quetype
                };
            } else if (item.category === 'QW5ub3kgZnVuIENhcmQ=') {
                answerData = {
                    annoyimage: item.answer?.annoyimage,
                    shapename: item.answer?.shapename,
                    nickname: item.answer?.nickname,
                    shapeUrl: item.answer?.shapeUrl,
                    fontname: item.answer?.fontname,
                    annoycardtitle: item.answer?.annoycardtitle,
                    annoyans: item.answer?.annoyans,
                    cardBg: item.answer?.cardBg,
                };
            } else if (item.category === 'RW1vdGlvbg==') {
                answerData = {
                    emotionBg: item.answer?.emotionBg,
                    emotionEmoji: item.answer?.emotionEmoji,
                    emotionContent: item.answer?.emotionContent,
                    emotionTitle: item.answer?.emotionTitle ?? null,
                    emotionVoice: item.answer?.emotionVoice
                };
            } else if (item.category === 'Q29uZmVzc2lvbg==') {
                answerData = {
                    confessionType: item.answer?.confessionType ?? null,
                    confessionTitle: item.answer?.confessionTitle ?? null,
                    confessionContent: item.answer?.confessionContent ?? null,
                    confessionVoice: item.answer?.confessionVoice ?? null,
                    confessionEmoji: item.answer?.confessionEmoji ?? null
                };

            } else if (item.category === 'UXVlc3Rpb24=') {
                answerData = {
                    confessionType: item.answer?.confessionType ?? null,
                    confessionTitle: item.answer?.confessionTitle ?? null,
                    confessionContent: item.answer?.confessionContent ?? null,
                    confessionVoice: item.answer?.confessionVoice ?? null,
                    confessionEmoji: item.answer?.confessionEmoji ?? null
                };

            } else if (item.category === 'SG90bmVzcw==') {
                answerData = {
                    hotnessBg: item.answer?.hotnessBg ?? null,
                    hotnessName: item.answer?.hotnessName ?? null,
                    hotnessEmoji: item.answer?.hotnessEmoji ?? null,
                    hotnessHand: item.answer?.hotnessHand ?? 'https://lol-image-bucket.s3.ap-south-1.amazonaws.com/images/question6/whitecard.png',
                    hotnessComment: item.answer?.hotnessComment ?? null
                };
            } else if (item.category === 'RnJpZW5k' || item.category === 'Q3J1c2g=' || item.category === 'TG92ZQ==') {
                answerData = {
                    friendBg: item.answer?.friendBg ?? null,
                    friendName: item.answer?.friendName ?? null,
                    friendEmoji: item.answer?.friendEmoji ?? null,
                    friendContent: item.answer?.friendContent ?? null
                };
            } else if (item.category === 'Um9hc3Q=') {
                answerData = {
                    roastType: item.answer?.roastType ?? null,
                    roastContent: item.answer?.roastContent ?? null,
                    roastVoice: item.answer?.roastVoice ?? null,
                    roastEmoji: item.answer?.roastEmoji ?? null
                };

            } else if (item.category === 'Qmx1ZmY=') {
                answerData = {
                    bluffBg: item.answer?.bluffBg ?? null,
                    bluffContent: item.answer?.bluffContent ?? null,
                    bluffEmoji: item.answer?.bluffEmoji ?? null,
                };

            } else if (item.category === 'Q2hhbGxlbmdl') {
                answerData = {
                    challengeContent: item.answer?.challengeContent ?? null,
                };

            } else if (item.category === 'SGVhdmVuSGVsbA==') {
                answerData = {
                    heavenHellQue: item.answer?.heavenHellQue,
                    heavenHellAns: item.answer?.heavenHellAns,
                    heavenHellContent: item.answer?.heavenHellContent,
                    heavenHellBg: item.answer?.heavenHellBg,
                    heavenHellAvatarImg: item.answer?.heavenHellAvatarImg,
                    heavenHellBgMdlImg: item.answer?.heavenHellBgMdlImg,
                    heavenHellType: item.answer?.heavenHellType,
                };
            } else {
                answerData = {
                    word: item.answer?.word,
                    contentFile: item.answer?.contentFile
                };
            }

            return {
                _id: item._id,
                category: item.category,
                question: item.question,
                hint: item.hint,
                hintImage: item.hintImage && item.hintImage.trim() !== ''
                    ? item.hintImage
                    : defaultHintImages[Math.floor(Math.random() * defaultHintImages.length)],
                hintContent: item.hintContent,
                hintAudio: item.hintAudio || null,
                location: item.location,
                country: item.country,
                ip: item.ip,
                time: item.time,
                createdAt: item.createdAt,
                updatedAt: item.updatedAt,
                answer: answerData
            };
        });

        res.status(200).json({
            status: 1,
            message: 'Data Found Successfully',
            data: customizedData,
        });

    } catch (error) {
        res.status(400).json({
            status: 0,
            error: error.message,
        });
    }
};

exports.Delete = async function (req, res, next) {
    try {

        const { inboxId } = req.body;

        if (!inboxId) {
            throw new Error("inbox value is required");

        }

        const inbox = await INBOX.findByIdAndDelete(inboxId);

        if (!inbox) {
            throw new Error("inbox not found");
        }

        res.status(200).json({
            status: 1,
            message: 'Card Delete Successfully',
        });
    } catch (error) {
        res.status(400).json({
            status: 0,
            message: error.message,
        });
    }
};

// ================================================= voice masking ============================================================

exports.VoiceMasking = async function (req, res, next) {
    try {
        res.status(201).json({
            status: 1,
            message: req.voiceConverted
                ? 'Voice converted successfully'
                : 'Voice uploaded successfully (conversion unavailable)',
            data: req.confessionVoiceUrl,
            audioStatus: req.audioStatus
        });
    } catch (error) {
        console.error('Full error object:', error);
        res.status(400).json({
            status: 0,
            message: error.message,
        });
    }
};

exports.VoiceMasking2 = async function (req, res, next) {
    try {
        res.status(201).json({
            status: 1,
            message: req.voiceConverted
                ? 'Voice converted successfully'
                : 'Voice uploaded successfully (conversion unavailable)',
            data: req.confessionVoiceUrl,
            audioStatus: req.audioStatus
        });
    } catch (error) {
        console.error('Full error object:', error);
        res.status(400).json({
            status: 0,
            message: error.message,
        });
    }
};